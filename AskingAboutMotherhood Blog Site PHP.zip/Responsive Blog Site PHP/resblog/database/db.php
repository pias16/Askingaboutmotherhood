<?php
	$database_username = 'root';//user name
	$database_password = '';//password
	$pdo_conn = new PDO( 'mysql:host=localhost;dbname=blog_admin_db', $database_username, $database_password );
?>
